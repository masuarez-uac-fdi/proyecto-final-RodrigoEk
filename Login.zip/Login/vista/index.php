<?php include 'partials/head.php'; ?>
<?php include 'partials/menu.php'; ?>

<div class="container">

  <div class="starter-template">
    <div class="jumbotron">
      <div class="container">
        <h1>Inicia Sesion</h1>
        <p>Para poder ser parte la comunidad debes iniciar tu sesion</p>
        <P>
          <a href="login.php" class="btn btn-primary btn-lg">Login</a>
        </P>
      </div>
    </div>
  </div>
</div>

</div>

<?php include 'partials/footer.php';?>